<template>
    <div>
        Profile
    </div>
</template>

<script>
    export default {}
</script>
