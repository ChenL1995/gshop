<template>
    <div>
        Search
    </div>
</template>

<script>
    export default {}
</script>
