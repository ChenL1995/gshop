<template>
  <div >
    app
  </div>
</template>

<script>

</script>

<style lang="stylus" rel="stylesheet/style">
  .app
    color:read
</style>
