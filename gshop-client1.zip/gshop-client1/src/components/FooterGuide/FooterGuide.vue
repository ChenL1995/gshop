<template>
    <div>
        <FooterGuide/>
    </div>
</template>

<script>
    export default {}
</script>
